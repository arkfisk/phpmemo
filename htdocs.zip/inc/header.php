<p style='text-align:right'>            
            <?php
            if (isset($_SESSION) === false){session_start();} // 다른 파일에서 세션이 시작되지 않았으면 세션 시작

            // 로그인 상태 여부(=세션에 id키가 있는지) 확인
            // 만약 로그아웃 상태라면 회원가입과 로그인 버튼을 보여줌
            if (isset($_SESSION['member_id']) === false){
            ?>
            <a href="/regist.php">회원가입</a>
            <a href="/login.php">로그인</a>
            <?php
            }else{ // 로그인 상태라면 로그아웃 버튼을 보여줌
            ?>
            <a href="/logout.php">로그아웃</a>
            <?php
            }
            ?>
        </p>