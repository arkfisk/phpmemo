<?php
// 메인 페이지에서, 이미 로그인 되어 있으면 방명록 목록으로 이동
session_start();
if (isset($_SESSION['member_id'])){
    header("Location: /list.php");
    exit();
}

// 로그인 되어있지 않을 경우 프로젝트 소개 페이지를 보여줌
?>
<!DOCTYPE html>
<html>
    <head>
        <title>방명록 목록</title>
    </head>
    <body>
        <?php require_once("inc/header.php"); ?>
        <h1>방명록 메인 페이지입니다</h1>
    </body>
</html>