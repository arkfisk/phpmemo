<?php
require_once("inc/db.php");

$login_id = isset($_POST['login_id']) ? $_POST['login_id'] : null;
$login_pw = isset($_POST['login_pw']) ? $_POST['login_pw'] : null;

// 파라미터 체크
if ($login_id == null || $login_pw == null){    
    header("Location: /login.php");
    exit();
}

// DB에서 회원 데이터를 가지고옴
$member_data = db_select("select * from tbl_member where login_id = ?", array($login_id));

// 회원 데이터가 없다면 로그인 실패 -> 로그인 화면으로 이동
if ($member_data == null || count($member_data) == 0){
    header("Location: /login.php");
    exit();
}

// 입력받은 비밀번호가 DB에 저장된 비밀번호과 같은지 체크
$is_match_password = password_verify($login_pw, $member_data[0]['login_pw']);

// 비밀번호가 다르면 로그인 페이지로 이동
if ($is_match_password === false){
    header("Location: /login.php");
    exit();
}

// 비밀번호가 같으면 로그인됐다는 정보를 세션에 저장
session_start();
$_SESSION['member_id'] = $member_data[0]['member_id'];

// 방명록 페이지으로 이동
header("Location: /list.php");
?>