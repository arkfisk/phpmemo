<?php
// DB 접속 파일 호출
require_once("inc/db.php"); 

// 파라미터를 변수에 저장
$login_id = isset($_POST['login_id']) ? $_POST['login_id'] : null;
$login_pw = isset($_POST['login_pw']) ? $_POST['login_pw'] : null;
$login_name = isset($_POST['login_name']) ? $_POST['login_name'] : null;

// 파라미터가 모두 있는지 체크
if ($login_id == null || $login_pw == null || $login_name == null){    
    header("Location: /regist.php");
    exit();
}

// 회원 가입이 되어 있는지 검사
// tbl_member 테이블에서 login_id 가 일치하는 회원 수를 세어봐서 
// 만약 회원이 있다면 1, 회원이 없다면 회원수가 0을 리턴
// 회원수가 1이라면 이미 같은 회원 ID가 존재하니까 회원가입 화면으로 리다이렉트함.
$member_count = db_select("select count(member_id) cnt from tbl_member where login_id = ?" , array($login_id));
if ($member_count && $member_count[0]['cnt'] == 1){    
    header("Location: /regist.php");
    exit();
}

// 비밀번호 암호화
$bcrypt_pw = password_hash($login_pw, PASSWORD_BCRYPT);

// 회원 정보 저장
db_insert("insert into tbl_member (login_id, login_name, login_pw) values (:login_id, :login_name, :login_pw )",
    array(
        'login_id' => $login_id,
        'login_name' => $login_name,
        'login_pw' => $bcrypt_pw
    )
);


// 로그인 페이지로 이동
header("Location: /login.php");
?>